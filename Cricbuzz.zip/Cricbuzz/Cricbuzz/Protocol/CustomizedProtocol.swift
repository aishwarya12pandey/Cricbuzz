//
//  ViewController.swift
//  Cricbuzz
//
//  Created by Aishwarya Pandey on 16/09/23.
//

import Foundation

protocol CustomizationProtocol{
    func initialize()
    func addListiner()
}
