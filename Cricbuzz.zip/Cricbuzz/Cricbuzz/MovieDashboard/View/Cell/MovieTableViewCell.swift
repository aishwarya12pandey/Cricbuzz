//
//  MovieTableViewCell.swift
//  Cricbuzz
//
//  Created by Aishwarya Pandey on 17/09/23.
//

import UIKit

class MovieTableViewCell: UITableViewCell {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var btnExpCollaps: UIButton!
    var viewModel =  MovieViewModel()
    var arrData = [MovieResponseModel]()
    var blockReloadTable: (()->())?
    var movieClosure: ((MovieResponseModel)->())?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        reloadInputViews()
        initialize()
    }
    func initialize() {
        tableView.register(UINib(nibName: "MovieCardTableViewCell", bundle: nil), forCellReuseIdentifier: "MovieCardTableViewCell")
        tableView.delegate = self
        tableView.dataSource = self
        
    }
    
    func setupData(index: Int) {
        let movieData = viewModel.allMovieDataByType[index]
        label.text = movieData.title
        btnExpCollaps.tag = index
        btnExpCollaps.isHidden = movieData.list.isEmpty
        if movieData.flag && !movieData.list.isEmpty{
            btnExpCollaps.isSelected = true
            tableViewHeight.constant = CGFloat(148*movieData.list.count)
            btnExpCollaps.setImage(UIImage(systemName: "chevron.down"), for: .normal)
        } else {
            btnExpCollaps.isSelected = false
            tableViewHeight.constant = 0
            btnExpCollaps.setImage(UIImage(systemName: "chevron.right"), for: .normal)
            
        }
        self.arrData = movieData.list
        tableView.reloadData()
    }
    
    @IBAction func buttonTap(_ sender: UIButton) {
        if viewModel.allMovieDataByType[sender.tag].flag {
            viewModel.allMovieDataByType[sender.tag].flag = false
        } else {
            for index in 0..<viewModel.allMovieDataByType.count {
                viewModel.allMovieDataByType[index].flag = false
            }
            viewModel.allMovieDataByType[sender.tag].flag = true
        }
        if blockReloadTable != nil {
            blockReloadTable!()
        }
    }
}

extension MovieTableViewCell: UITableViewDataSource,UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MovieCardTableViewCell", for: indexPath) as? MovieCardTableViewCell
        cell?.updateValue(data: arrData[indexPath.row])
        return cell ?? UITableViewCell()
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 148
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.movieClosure?(arrData[indexPath.row])
    }
    
}
