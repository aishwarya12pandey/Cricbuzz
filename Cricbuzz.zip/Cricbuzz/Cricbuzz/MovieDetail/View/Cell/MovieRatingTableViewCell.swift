//
//  MovieRatingTableViewCell.swift
//  Cricbuzz
//
//  Created by Aishwarya Pandey on 18/09/23.
//

import UIKit

class MovieRatingTableViewCell: UITableViewCell {

    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var segmentView: UISegmentedControl!
    var ratingData = [Ratings]()
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    func updateData(data: MovieResponseModel){
        segmentView.selectedSegmentIndex = 0
        var j = 0
        segmentView.removeAllSegments()
        ratingLabel.text = data.ratings?.first?.value
        ratingData = data.ratings ?? [Ratings]()
        for i in ratingData{
            segmentView.insertSegment(withTitle: i.source, at: j, animated: true)
            j += 1
        }

    }

    @IBAction func segmentControl(_ sender: UISegmentedControl) {
        let selectedIndex = sender.selectedSegmentIndex
        ratingLabel.text = ratingData[selectedIndex].value

    }
}
