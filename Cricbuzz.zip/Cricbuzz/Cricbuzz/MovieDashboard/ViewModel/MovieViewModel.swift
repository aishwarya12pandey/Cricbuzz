//
//  MovieViewModel.swift
//  Cricbuzz
//
//  Created by Aishwarya Pandey on 16/09/23.
//

import Foundation

class MovieViewModel{
    
    var allMovies: [MovieResponseModel] = []
    
    struct MovieDataByType {
        var title = ""
        var list = [MovieResponseModel]()
        var flag = false
    }
    
    var allMovieDataByType = [MovieDataByType]()
    
    var reloadData: Bindable<Bool> = Bindable(false)
    
    struct TopTitleData {
        var title = ""
        var flag = false
    }
    
    var movieArray = [TopTitleData(title: "Year", flag: false),
                      TopTitleData(title: "Genre", flag: false),
                      TopTitleData(title: "Directors", flag: false),
                      TopTitleData(title: "Actors", flag: false),
                      TopTitleData(title: "AllMovies", flag: false)]
    
    func fetchData(){
        let path = Bundle.main.path(forResource: "movies", ofType: "json")
        let data = try! NSData(contentsOfFile: path!, options: NSData.ReadingOptions.mappedIfSafe) as Data
        
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        do{
            let detail = try decoder.decode([MovieResponseModel].self, from: data)
            allMovies = detail
        } catch {
            print(error)
        }
    }
    
    
    func getMovieCategoryData(allMovieData: [MovieResponseModel], type: MovieType){
        allMovieDataByType = []
        switch type {
        case .Year:
            let years = allMovieData.compactMap({$0.year ?? ""})
            let setArray = Array(Set(years))
            
            for year in setArray {
                let arr = allMovieData.filter { obj in
                    if let y = obj.year, y == year {
                        return true
                    }
                    return false
                }
                allMovieDataByType.append(MovieDataByType(title: year, list: arr, flag: false))
            }
        case .Genre:
            let genres = allMovieData.compactMap({$0.genre ?? ""})
            let setArray = Array(Set(genres))
            
            for genre in setArray {
                let arr = allMovieData.filter { obj in
                    if let y = obj.genre, y == genre {
                        return true
                    }
                    return false
                }
                allMovieDataByType.append(MovieDataByType(title: genre, list: arr, flag: false))
            }
        case .Directors:
            let directors = allMovieData.compactMap({$0.director})
            let setArray = Array(Set(directors))
            
            for director in setArray {
                let arr = allMovieData.filter { obj in
                    if let y = obj.director, y == director {
                        return true
                    }
                    return false
                }
                allMovieDataByType.append(MovieDataByType(title: director, list: arr, flag: false))
            }
        case .Actors:
            let actorses = allMovieData.compactMap({$0.actors ?? ""})
            let setArray = Array(Set(actorses))
            
            for actors in setArray {
                let arr = allMovieData.filter { obj in
                    if let y = obj.actors, y == actors {
                        return true
                    }
                    return false
                }
                allMovieDataByType.append(MovieDataByType(title: actors, list: arr, flag: false))
            }
        case .AllMovies:
            allMovieDataByType.append(MovieDataByType(title: "Movies", list: allMovieData, flag: false))
        }
    }
}
