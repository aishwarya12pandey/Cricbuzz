//
//  MovieDetailController.swift
//  Cricbuzz
//
//  Created by Aishwarya Pandey on 18/09/23.
//

import UIKit
import SDWebImage

class MovieDetailController: UIViewController {
    @IBOutlet weak var tableViewInstance : UITableView!
    
    var titleArray = ["title","cast & crew","released date","genre"]
    
    var movieResponse: MovieResponseModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialize()
    }
    func initialize() {
        tableViewInstance.register(UINib(nibName: "MovieDetailTableViewCell", bundle: nil), forCellReuseIdentifier: "MovieDetailTableViewCell")
        tableViewInstance.register(UINib(nibName: "MoviePosterTableViewCell", bundle: nil), forCellReuseIdentifier: "MoviePosterTableViewCell")
        tableViewInstance.register(UINib(nibName: "MovieRatingTableViewCell", bundle: nil), forCellReuseIdentifier: "MovieRatingTableViewCell")
        
        
        tableViewInstance.delegate = self
        tableViewInstance.dataSource = self
    }
}
extension MovieDetailController: UITableViewDataSource,UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 || section == 1{
            return 1
        }else{
            return titleArray.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "MoviePosterTableViewCell", for: indexPath) as? MoviePosterTableViewCell
            cell?.movieImage.sd_imageIndicator = SDWebImageActivityIndicator.gray
            cell?.movieImage.sd_setImage(with: URL(string: movieResponse?.poster ?? ""), completed: nil)
            return cell ?? UITableViewCell()
        }else if indexPath.section == 1{
            let cell = tableView.dequeueReusableCell(withIdentifier: "MovieRatingTableViewCell", for: indexPath) as? MovieRatingTableViewCell
            if let data = movieResponse{
                cell?.updateData(data: data)
            }
            return cell ?? UITableViewCell()
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "MovieDetailTableViewCell", for: indexPath) as? MovieDetailTableViewCell
            cell?.titleLabel.text = titleArray[indexPath.row]
            switch indexPath.row{
            case 0:
                cell?.movieDesLabel.text = movieResponse?.title
            case 1:
                cell?.movieDesLabel.text = movieResponse?.actors
            case 2:
                cell?.movieDesLabel.text = movieResponse?.released
            case 3:
                cell?.movieDesLabel.text = movieResponse?.genre
            default:
                break
            }
            return cell ?? UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
}

