//
//  Bindable.swift
//  Cricbuzz
//
//  Created by Aishwarya Pandey on 16/09/23.
//

import Foundation

class Bindable<T>{
    typealias Listiner = (T) -> Void
    
    var listiner: Listiner?
    
    var value: T{
        didSet{
            self.listiner?(value)
        }
    }
    
    init(_ value: T) {
        self.value = value
    }
    
    func bind(listiner: @escaping Listiner){
        self.listiner = listiner
    }
}
