//
//  MovieCardTableViewCell.swift
//  Cricbuzz
//
//  Created by Aishwarya Pandey on 17/09/23.
//

import UIKit
import SDWebImage

class MovieCardTableViewCell: UITableViewCell {
    
    @IBOutlet weak var movieTitle: UILabel!
    @IBOutlet weak var movieYearLabel: UILabel!
    @IBOutlet weak var languagelabel: UILabel!
    @IBOutlet weak var thumbnailImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func updateValue(data: MovieResponseModel){
        thumbnailImage.sd_imageIndicator = SDWebImageActivityIndicator.gray
        thumbnailImage.sd_setImage(with: URL(string: data.poster ?? ""), completed: nil)
        movieTitle.text = data.title
        movieYearLabel.text = data.year
        languagelabel.text = data.language
    }
    
}
