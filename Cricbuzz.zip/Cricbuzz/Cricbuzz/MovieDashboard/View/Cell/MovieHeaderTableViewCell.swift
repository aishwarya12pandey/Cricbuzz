//
//  MovieHeaderTableViewCell.swift
//  Cricbuzz
//
//  Created by Aishwarya Pandey on 17/09/23.
//

import UIKit

class MovieHeaderTableViewCell: UITableViewCell {

    @IBOutlet weak var btnExpandCollapse: UIButton!
    @IBOutlet weak var movieTitle: UILabel!
    var movieCallBack: (() -> ())?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    @IBAction func expandButtonTap(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        movieCallBack?()
    }
    
}
