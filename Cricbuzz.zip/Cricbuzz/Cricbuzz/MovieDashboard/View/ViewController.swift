//
//  ViewController.swift
//  Cricbuzz
//
//  Created by Aishwarya Pandey on 16/09/23.
//

import UIKit

class ViewController: UIViewController {
    var viewModel = MovieViewModel()
    @IBOutlet weak var tableViewInstance : UITableView!
    var movieType: MovieType? {
        didSet {
            if let movieType = movieType {
                viewModel.getMovieCategoryData(allMovieData: viewModel.allMovies, type: movieType)
            } else {
                viewModel.allMovieDataByType = []
            }
            tableViewInstance.reloadData()
        }
    }
    var movieResponeModel = [MovieResponseModel]()
    var dropDownStatus = false
    var selectedIndex: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addListiner()
        initialize()
    }
}

extension ViewController: CustomizationProtocol{
    func initialize() {
        viewModel.fetchData()
        tableViewInstance.register(UINib(nibName: "MovieHeaderTableViewCell", bundle: nil), forCellReuseIdentifier: "MovieHeaderTableViewCell")
        tableViewInstance.register(UINib(nibName: "MovieTableViewCell", bundle: nil), forCellReuseIdentifier: "MovieTableViewCell")
        tableViewInstance.delegate = self
        tableViewInstance.dataSource = self
    }
    
    func addListiner() {
        viewModel.reloadData.bind { [weak self] (status) in
            if status{
                guard let self = self  else { return }
                self.tableViewInstance.reloadData()
            }
        }
    }
}
extension ViewController: UITableViewDataSource,UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.viewModel.movieArray.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.viewModel.movieArray[section].flag{
            return self.viewModel.allMovieDataByType.count
        }else{
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MovieHeaderTableViewCell") as? MovieHeaderTableViewCell
        cell?.movieTitle.text = self.viewModel.movieArray[section].title
        if dropDownStatus == true && selectedIndex == section{
            cell?.btnExpandCollapse.setImage(UIImage(systemName: "chevron.down"), for: .normal)
        }else{
            cell?.btnExpandCollapse.setImage(UIImage(systemName: "chevron.right"), for: .normal)
        }
        cell?.movieCallBack = {[weak self] in
            guard let self = self else { return }
            if self.viewModel.movieArray[section].flag {
                self.viewModel.movieArray[section].flag = false
                self.dropDownStatus = false
                self.selectedIndex = section
            } else {
                for index in 0..<self.viewModel.movieArray.count {
                    self.viewModel.movieArray[index].flag = false
                }
                self.viewModel.movieArray[section].flag = true
                self.dropDownStatus = true
                self.selectedIndex = section
            }
            self.movieType = MovieType(rawValue: self.viewModel.movieArray[section].title)
            self.tableViewInstance.reloadData()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MovieTableViewCell", for: indexPath) as? MovieTableViewCell
        cell?.initialize()
        cell?.viewModel = viewModel
        cell?.setupData(index: indexPath.row)
        cell?.blockReloadTable = { () -> Void in
            self.tableViewInstance.reloadData()
        }
        cell?.movieClosure = {[weak self] (movieData) in
            let vc = MovieDetailController()
            vc.movieResponse = movieData
            self?.navigationController?.pushViewController(vc, animated: true)
        }
        return cell ?? UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
}

